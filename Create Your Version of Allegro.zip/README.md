
  # Create Your Version of Allegro

  This is a code bundle for Create Your Version of Allegro. The original project is available at https://www.figma.com/design/WzZTSmtQHoysXnGttuh0rM/Create-Your-Version-of-Allegro.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  