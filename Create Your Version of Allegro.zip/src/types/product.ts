export interface Product {
  id: number;
  title: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  seller: string;
  rating: number;
  reviewCount: number;
  delivery: string;
  isFreeDelivery: boolean;
  isSmart: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}
