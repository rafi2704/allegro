import { Star, Truck, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Product } from '../types/product';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="bg-white rounded-lg border hover:shadow-lg transition-shadow cursor-pointer group">
      <div className="relative p-4">
        <div className="absolute top-6 right-6 z-10">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 bg-white/80 hover:bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>
        
        {discount > 0 && (
          <Badge className="absolute top-6 left-6 bg-red-600 hover:bg-red-600">
            -{discount}%
          </Badge>
        )}
        
        {product.isSmart && (
          <Badge className="absolute top-6 left-6 mt-8 bg-purple-600 hover:bg-purple-600">
            SMART
          </Badge>
        )}

        <div className="aspect-square relative overflow-hidden rounded-lg mb-4">
          <ImageWithFallback
            src={product.image}
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>

        <div className="space-y-2">
          <h3 className="text-sm line-clamp-2 min-h-[2.5rem]">{product.title}</h3>

          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-orange-400 text-orange-400" />
            <span className="text-sm">{product.rating}</span>
            <span className="text-xs text-gray-500">({product.reviewCount})</span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-2xl text-orange-600">{product.price.toFixed(2)} zł</span>
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                {product.originalPrice.toFixed(2)} zł
              </span>
            )}
          </div>

          {product.isFreeDelivery && (
            <div className="flex items-center gap-1 text-green-600">
              <Truck className="h-4 w-4" />
              <span className="text-sm">Darmowa dostawa</span>
            </div>
          )}

          <div className="text-xs text-gray-600">
            Dostawa: <span>{product.delivery}</span>
          </div>

          <Button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product);
            }}
            className="w-full bg-orange-600 hover:bg-orange-700"
          >
            Dodaj do koszyka
          </Button>
        </div>
      </div>
    </div>
  );
}
