import { SlidersHorizontal } from 'lucide-react';
import { Button } from './ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface FilterBarProps {
  sortBy: string;
  onSortChange: (value: string) => void;
  resultCount: number;
}

export function FilterBar({ sortBy, onSortChange, resultCount }: FilterBarProps) {
  return (
    <div className="bg-white border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="text-sm text-gray-600">
          Znaleziono <span>{resultCount}</span> produktów
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm">Sortuj:</span>
            <Select value={sortBy} onValueChange={onSortChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Trafność</SelectItem>
                <SelectItem value="price-asc">Cena: od najniższej</SelectItem>
                <SelectItem value="price-desc">Cena: od najwyższej</SelectItem>
                <SelectItem value="rating">Ocena</SelectItem>
                <SelectItem value="popularity">Popularność</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button variant="outline" size="sm">
            <SlidersHorizontal className="h-4 w-4 mr-2" />
            Filtry
          </Button>
        </div>
      </div>
    </div>
  );
}
