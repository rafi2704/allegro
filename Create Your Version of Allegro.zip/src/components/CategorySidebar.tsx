import { ChevronRight } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  count: number | null;
}

interface CategorySidebarProps {
  categories: Category[];
  selectedCategory: string;
  onCategorySelect: (categoryId: string) => void;
}

export function CategorySidebar({ categories, selectedCategory, onCategorySelect }: CategorySidebarProps) {
  return (
    <aside className="bg-white rounded-lg border p-4">
      <h2 className="mb-4">Kategorie</h2>
      <nav>
        <ul className="space-y-1">
          {categories.map((category) => (
            <li key={category.id}>
              <button
                onClick={() => onCategorySelect(category.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-md transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-orange-50 text-orange-600'
                    : 'hover:bg-gray-50'
                }`}
              >
                <span className="text-sm">{category.name}</span>
                <div className="flex items-center gap-2">
                  {category.count !== null && (
                    <span className="text-xs text-gray-500">({category.count})</span>
                  )}
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </div>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}
