import { ShoppingCart, User, Heart, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface HeaderProps {
  cartItemCount: number;
  onCartClick: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function Header({ cartItemCount, onCartClick, searchQuery, onSearchChange }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white border-b">
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white py-2">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="text-sm">Kup Teraz</span>
            <span className="text-sm">Sprzedaj</span>
            <span className="text-sm">Pomoc</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="text-white hover:bg-orange-700 h-8">
              <User className="h-4 w-4 mr-2" />
              Moje konto
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="text-orange-600 text-3xl">
              <svg viewBox="0 0 100 40" className="h-10 w-24">
                <text x="0" y="30" className="fill-current" style={{ fontSize: '28px' }}>
                  ShopHub
                </text>
              </svg>
            </div>
          </div>

          <div className="flex-1 relative">
            <div className="flex">
              <Input
                type="text"
                placeholder="Czego szukasz?"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="rounded-r-none pr-4"
              />
              <Button className="rounded-l-none bg-orange-600 hover:bg-orange-700">
                <Search className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="relative" onClick={onCartClick}>
              <ShoppingCart className="h-5 w-5" />
              {cartItemCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-orange-600">
                  {cartItemCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
